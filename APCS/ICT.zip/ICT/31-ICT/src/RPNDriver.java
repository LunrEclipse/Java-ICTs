import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

public class RPNDriver {
    public static void main (String[]args)
    {
       RPN test = new RPN();
       test.run();
    }
}
