
public class SortDriver
{
    public static void main(String[] args)
    {     
        SortStep n00b = new SortStep();
        n00b.sortMenu();
    }
}

