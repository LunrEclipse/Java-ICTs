import java.io.IOException;

public class Driver {
    public static void main(String[] args) throws IOException {
        HeapSort test = new HeapSort();
        test.sort();
    }
}
