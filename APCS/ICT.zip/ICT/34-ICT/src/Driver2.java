import java.io.IOException;

public class Driver2 {
    public static void main(String[] args) throws IOException {
        HeapSort test = new HeapSort();
        test.mainMenu();
    }
}
