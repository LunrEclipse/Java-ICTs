import java.io.*;

public class Test {
    public static void main(String[] args)
    {
        ArrayList<String> test = new ArrayList<String>(6);
        test.get(0);
    }
}
