public class Driver {
    public static void main(String[] args)
    {
        Main test = new Main();
        test.mainMenu();
    }
}
