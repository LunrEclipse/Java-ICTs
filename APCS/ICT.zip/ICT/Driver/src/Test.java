import java.io.*;
import java.util.ArrayList;
import java.util.PriorityQueue;

public class Test {
    public static void main(String[] args)
    {
        PriorityQueue<String> temp = new PriorityQueue<String>();
        //System.out.println(temp.remove());
        temp.remove();
    }
}
