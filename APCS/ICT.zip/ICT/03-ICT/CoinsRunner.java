public class CoinsRunner
{
    public static void main(String[] args)  
    {
        Coins test1; 
        test1 = new Coins (94);
        test1.calculate();
        
        Coins test2; 
        test2 = new Coins (59);
        test2.calculate();
        
        Coins test3; 
        test3 = new Coins (19);
        test3.calculate();
    }
}