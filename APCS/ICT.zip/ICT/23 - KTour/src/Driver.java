public class Driver {
    public static void main (String[] args)
    {
        KTour test = new KTour();
        test.run();
        test.print();
    }
}
