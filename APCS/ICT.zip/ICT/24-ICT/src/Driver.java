public class Driver {
    public static void main (String[] args)
    {
        Eraser test = new Eraser ("digital.txt");
        test.run();
    }
}
