public class CircularlyDriver {
    public static void main(String[] args)
    {
        COrderedList test = new COrderedList();
        CircularlyLinkedList list = new CircularlyLinkedList();
        test.mainMenu(list);
    }
}
