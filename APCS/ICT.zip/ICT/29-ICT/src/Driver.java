public class Driver {
    public static void main(String[] args)
    {
        System.out.println("Lab One:\n\n");
        ListDemo test = new ListDemo();
        test.createList();
        test.displayFirst();
        test.displayLast();
        test.print();
        test.getNodes();
    }
}
