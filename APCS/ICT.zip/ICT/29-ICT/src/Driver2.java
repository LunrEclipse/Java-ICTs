public class Driver2 {
    public static void main(String[] args)
    {
OrderedList test = new OrderedList();
SinglyLinkedList list = new SinglyLinkedList();
test.mainMenu(list);
    }
}
