public class DoubleDriver {
    public static void main(String[] args)
    {
        DOrderedList test = new DOrderedList();
        DoublyLinkedList list = new DoublyLinkedList();
        test.mainMenu(list);
    }
}
