public class ItemDriver {
    public static void main(String[] args)
    {
        BSTree test = new BSTree();
        BinarySearchTree tree = new BinarySearchTree();
        test.mainMenu(tree);
    }
}
