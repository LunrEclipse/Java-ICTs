public class Driver {
    public static void main (String[] args)
    {
        KTour2 test = new KTour2("access.txt");
        test.run();
        test.print();
    }
}
