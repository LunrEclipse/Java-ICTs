public class Driver {
    public static void main (String[] args)
    {
        Hashing test = new Hashing();
        test.loadFile();
        test.search();
        test.stats();
    }

}
