public class OldMacDonald
{
  public static void main(String[] args)
  {
    Farm animalFarm = new Farm();
    animalFarm.animalSounds();
  }
}
